﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace SPro_Cursova_Rabota
{
    public class GraphControl : Control
    {
        public GraphControl()
        {
            Loaded += GraphControl_Loaded;
            SizeChanged += GraphControl_SizeChanged;
            DataContextChanged += GraphControl_DataContextChanged;
            pen = new Pen(Brushes.Black, 1);
            linePen = new Pen(Brushes.Indigo, 1);
        }
        private Pen pen;
        private Pen linePen;
        private void GraphControl_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if(e.NewValue is ApplicationViewModel)
            {
                ApplicationViewModel vm = (ApplicationViewModel)e.NewValue;
                vm.MaxX = MaxX;
                vm.MaxY = MaxY;
                vm.Calculate();
               
            }
        }

        private void GraphControl_Loaded(object sender, RoutedEventArgs e)
        {
            MaxX = ActualWidth;
            MaxY = ActualHeight;
        }

        private void GraphControl_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            MaxX = e.NewSize.Width;
            MaxY = e.NewSize.Height;
            Refresh?.Execute(null);
        }

        

        protected override void OnRender(DrawingContext dc)
        {
            dc.DrawLine(pen, new Point(ActualWidth/2, 0), new Point(ActualWidth/2, ActualHeight));
            dc.DrawLine(pen, new Point(0, ActualHeight/2), new Point(ActualWidth, ActualHeight/2));

            if (ListOfPoints == null)
                return;

            

            Rect rect = new Rect(0, 0, ActualWidth, ActualHeight);
            Point centeredPoint = new Point();

            for (int i = 1; i < ListOfPoints.Count; i++)
            {
                centeredPoint.X = ListOfPoints[i].X + (ActualWidth / 2);
                centeredPoint.Y = ListOfPoints[i].Y + (ActualHeight / 2);
                if (rect.Contains(centeredPoint))
                    dc.DrawEllipse(Brushes.Red, null,  centeredPoint,  1, 1);                         
            }


        }

        public static readonly DependencyProperty ListOfPointsProperty = DependencyProperty.Register("ListOfPoints", typeof(List<Point>), typeof(GraphControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

        public List<Point> ListOfPoints
        {
            get => (List<Point>)GetValue(ListOfPointsProperty);
            set => SetValue(ListOfPointsProperty, value);
        }

        public static readonly DependencyProperty MaxXProperty = DependencyProperty.Register("MaxX", typeof(double), typeof(GraphControl), new FrameworkPropertyMetadata(0d, FrameworkPropertyMetadataOptions.AffectsRender));

        public double MaxX
        {
            get => (double)GetValue(MaxXProperty);
            set => SetValue(MaxXProperty, value);
        }

        public static readonly DependencyProperty MaxYProperty = DependencyProperty.Register("MaxY", typeof(double), typeof(GraphControl), new FrameworkPropertyMetadata(0d, FrameworkPropertyMetadataOptions.AffectsRender));

        public double MaxY
        {
            get => (double)GetValue(MaxYProperty);
            set => SetValue(MaxYProperty, value);
        }

        public static readonly DependencyProperty RefreshProperty = DependencyProperty.Register(nameof(Refresh), typeof(ICommand), typeof(GraphControl), new FrameworkPropertyMetadata(null));

        public ICommand Refresh
        {
            get => (ICommand)GetValue(RefreshProperty);
            set => SetValue(RefreshProperty, value);
        } 
    }
}
