﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime;
using System.Windows;
using System.Windows.Media;
using System.Runtime.Remoting.Channels;


namespace SPro_Cursova_Rabota
{
    public class LinearFunction : ApplicationViewModel
    {
        private double _k;
        private double _b;
        
        public LinearFunction()
        {
            k = 1;
            b = 0;
        }

        public double k
        {
            get { return _k; }
            set
            {
                if (_k != value)
                {
                    _k = value;
                    OnPropertyChanged(nameof(k));
                    OnPropertyChanged(nameof(FunctionExpression));
                    Calculate();
                    FunctionExpression = $"f(x) = {k}x + {b}";
                }
                    
            }
        }

        public double b
        {
            get { return _b; }
            set
            {
                if (_b != value)
                {
                    _b = value;
                    OnPropertyChanged(nameof(k));
                    OnPropertyChanged(nameof(FunctionExpression));
                    Calculate();
                    FunctionExpression = $"f(x) = {k}x + {b}";
                }
                    
            }
        }

        private string _FunctionExpression;
        public string FunctionExpression
        {
            get { return _FunctionExpression; }
            set { _FunctionExpression = value; OnPropertyChanged(nameof(FunctionExpression)); }
        }

        public override void Calculate()
        {
            double y, x;

            List<Point> points = new List<Point>();
            double Koef = Math.PI / 180;
            for (double i = -250; i < 250; i += 0.1)
            {
                x = i;
                y = k * x + b;
                points.Add(new Point(x, y));
            }
            Points = points;
        }

    }

    public class SquareFunction : ApplicationViewModel
    {
        private double _a;
        
        public SquareFunction()
        {
            a = 1;
        }

        public double a
        {
            get { return _a; }
            set
            {
                if (_a != value)
                {
                    _a = value;
                    OnPropertyChanged(nameof(a));
                    Calculate();
                    FunctionExpression = $"f(x) = {a}х^2";
                }
            }
        }


        private string _FunctionExpression;
        public string FunctionExpression
        {
            get { return _FunctionExpression; }
            set { _FunctionExpression = value; OnPropertyChanged(nameof(FunctionExpression)); }
        }


        public override void Calculate()
        {
            double x, y;
            List<Point> points = new List<Point>();
            double Koef = Math.PI / 180;
            for (double i = -250; i < 250; i += 0.1)
            {
                x = i;
                y = -Math.Pow(x, 2)*a;
                points.Add(new Point(x, y));
            }
            Points = points;
        }

    }

    public class LogFunction : ApplicationViewModel
    {
        public LogFunction()
        {
            a = 1;
        }

        private double _a;
        public double a
        {
            get { return _a; }
            set
            {
                if (_a != value)
                {
                    _a = value;
                    OnPropertyChanged(nameof(a));
                    Calculate();
                    FunctionExpression = $"f(x) = log({a}X)";
                }   
            }
        }

        private string _FunctionExpression;
        //$"f(x) = log{a}X"
        public string FunctionExpression
        {
            get { return _FunctionExpression; }
            set { _FunctionExpression = value; OnPropertyChanged(nameof(FunctionExpression)); }
        }


        public override void Calculate()
        {
            double y, x;
            List<Point> points = new List<Point>();
            double Koef = Math.PI / 180;
            for (double i = -250; i < 250; i += 0.1)
            {
                x = i;
                y = -Math.Log(x*a)*10;
                points.Add(new Point(x, y));
            }
            Points = points;
        }
    }

    public class SinFunction : ApplicationViewModel
    {
        private double _a;
        private double _b;

        public SinFunction()
        {
            a = 1;
            b = 1;
        }

        public double b
        {
            get { return _b; }
            set
            {
                if (_b != value)
                {
                    _b = value;
                    OnPropertyChanged(nameof(b));
                    Calculate();
                    FunctionExpression = $"f(x) = {a}sin({b}x)";
                }
            }
        }

        public double a
        {
            get { return _a; }
            set
            {
                if (_a != value)
                {
                    _a = value;
                    OnPropertyChanged(nameof(a));
                    Calculate();
                    FunctionExpression = $"f(x) = {a}sin({b}x)";
                }
                    
            }
        }

        private string _FunctionExpression;

        public string FunctionExpression
        {
            get { return _FunctionExpression; }
            set {  _FunctionExpression = value; OnPropertyChanged(nameof(FunctionExpression)); }
        }


        public override void Calculate()
        {
            double y, x;
            List<Point> points = new List<Point>();
            double Koef = Math.PI / 180;
            for (double i = -250; i < 250; i += 0.1)
            {
                x = i;
                y = a * -Math.Sin(b * x * Koef) * 10;// умножаем на 10 чтобы по красоте было
                points.Add(new Point(x, y));
            }
            Points = points;
        }
    }

    public class CosFunction : ApplicationViewModel
    {
        private double _a;
        private double _b;

        public CosFunction()
        {
            a = 1;
            b = 1;
        }


        public double b
        {
            get { return _b; }
            set
            {
                if (_b != value)
                    _b = value;
                OnPropertyChanged(nameof(b));
                Calculate();
                FunctionExpression = $"f(x) = {a}cos({b}x)";
            }
        }

        public double a
        {
            get { return _a; }
            set
            {
                if (_a != value)
                    _a = value;
                OnPropertyChanged(nameof(a));
                Calculate();
                FunctionExpression = $"f(x) = {a}cos({b}x)";
            }
        }
        
        private string _FunctionExpression;
        public string FunctionExpression
        {
            get { return _FunctionExpression; }
            set { _FunctionExpression = value;  OnPropertyChanged(nameof(FunctionExpression)); }
        }


        public override void Calculate()
        {
            double y, x;

            List<Point> points = new List<Point>();
            double Koef = Math.PI / 180;
            for (double i = -250; i < 250; i += 0.1)
            {
                x = i;
                y = a * -Math.Cos(b * x * Koef) * 10;// -||-
                points.Add(new Point(x, y));
            }
            Points = points;
        }
    }

    public class TanFunction : ApplicationViewModel
    {
        private double _a;
        private double _b;

        public TanFunction()
        {
            a = 1;
            b = 1;
        }

        public double a
        {
            get { return _a; }
            set
            {
                if (_a != value)
                    _a = value;
                OnPropertyChanged(nameof(a));
                Calculate();
                FunctionExpression = $"f(x) = {a}tan({b}x)";
            }
        }

        public double b
        {
            get { return _b; }
            set
            {
                if (_b != value)
                    _b = value;
                OnPropertyChanged(nameof(b));
                Calculate();
                FunctionExpression = $"f(x) = {a}tan({b}x)";
            }
        }

        private string _FunctionExpression;

        public string FunctionExpression
        {
            get { return _FunctionExpression; }
            set { _FunctionExpression = value; OnPropertyChanged(nameof(FunctionExpression)); }
        }

        public override void Calculate()
        {
            double y, x;

            List<Point> points = new List<Point>();
            double Koef = Math.PI / 180;
            for (double i = -250; i < 250; i += 0.1)
            {
                x = i;
                y = a*-Math.Tan(b * x * Koef);
                points.Add(new Point(x, y));
            }
            Points = points;          
        }

    }

}