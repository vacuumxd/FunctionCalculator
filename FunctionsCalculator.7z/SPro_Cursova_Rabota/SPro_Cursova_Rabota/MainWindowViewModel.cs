﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace SPro_Cursova_Rabota
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private bool _LogIsChecked;
        public bool LogIsChecked
        {
            get
            {
                return _LogIsChecked;
            }
            set
            {
                if( _LogIsChecked != value )
                {
                _LogIsChecked = value;
                OnPropertyChanged(nameof(LogIsChecked));
                    if (LogIsChecked)
                    {
                        LinearIsChecked = false;
                        SquareIsChecked = false;
                        SinIsChecked = false;
                        CosIsChecked = false;
                        TanIsChecked = false;
                    }
                    

                }
            }
        }

        private bool _LinearIsChecked;
        public bool LinearIsChecked
        {
            get
            {
                return _LinearIsChecked;
            }
            set
            {
                if (_LinearIsChecked != value)
                {
                    _LinearIsChecked = value;
                    OnPropertyChanged(nameof(LinearIsChecked));
                    if (LinearIsChecked)
                    {
                        LogIsChecked = false;
                        SquareIsChecked = false;
                        SinIsChecked = false;
                        CosIsChecked = false;
                        TanIsChecked = false;
                    }
                }
            }
        }
        private bool _SquareIsChecked;
        public bool SquareIsChecked
        {
            get
            {
                return _SquareIsChecked;
            }
            set
            {
                if (_SquareIsChecked != value)
                {
                    _SquareIsChecked = value;
                    OnPropertyChanged(nameof(SquareIsChecked));
                    if (SquareIsChecked)
                    {
                        LogIsChecked = false;
                        LinearIsChecked = false;
                        SinIsChecked = false;
                        CosIsChecked = false;
                        TanIsChecked = false;
                    }
                }
            }
        }

        private bool _SinIsChecked;
        public bool SinIsChecked
        {
            get
            {
                return _SinIsChecked;
            }
            set
            {
                if (_SinIsChecked != value)
                {
                    _SinIsChecked = value;
                    OnPropertyChanged(nameof(SinIsChecked));
                    if (SinIsChecked)
                    {
                        LogIsChecked = false;
                        LinearIsChecked = false;
                        SquareIsChecked = false;
                        CosIsChecked = false;
                        TanIsChecked = false;
                    }
                }
            }
        }

        private bool _CosIsChecked;
        public bool CosIsChecked
        {
            get
            {
                return _CosIsChecked;
            }
            set
            {
                if (_CosIsChecked != value)
                {
                    _CosIsChecked = value;
                    OnPropertyChanged(nameof(CosIsChecked));
                    if (CosIsChecked)
                    {
                        LogIsChecked = false;
                        LinearIsChecked = false;
                        SquareIsChecked = false;
                        SinIsChecked = false;
                        TanIsChecked = false;
                    }
                }
            }
        }

        private bool _TanIsChecked;
        public bool TanIsChecked
        {
            get
            {
                return _TanIsChecked;
            }
            set
            {
                if (_TanIsChecked != value)
                {
                    _TanIsChecked = value;
                    OnPropertyChanged(nameof(TanIsChecked));
                    if (TanIsChecked)
                    {
                        LogIsChecked = false;
                        LinearIsChecked = false;
                        SquareIsChecked = false;
                        SinIsChecked = false;
                        CosIsChecked = false;
                    }
                }
            }
        }

        private bool _IsFileLoaded;

        public bool IsFileLoaded
        {
            get { return _IsFileLoaded; }
            set
            {
                _IsFileLoaded = value; OnPropertyChanged(nameof(IsFileLoaded));
                if(IsFileLoaded)
                {
                    LogIsChecked = false;
                    LinearIsChecked = false;
                    SquareIsChecked = false;
                    SinIsChecked = false;
                    CosIsChecked = false;
                    TanIsChecked = false;
                }
            }
        }

    public MainWindowViewModel()
        {
            Points = new List<Point>();
            IsFileLoaded = false;


            Functions = new ObservableCollection<ApplicationViewModel> ();
            Functions.Add(new LogFunction() { Name="Log Function"}); 
            Functions.Add(new LinearFunction() { Name = "Linear Function" });
            Functions.Add(new SquareFunction() { Name = "Square Function" });
            Functions.Add(new SinFunction() { Name = "Sin Function" });
            Functions.Add(new CosFunction() { Name = "Cos Function" });
            Functions.Add(new TanFunction() { Name = "Tan Function" });


            LogIsChecked= false;
            LinearIsChecked = false;
            SquareIsChecked = false;
            SinIsChecked = false;
            CosIsChecked = false;
            TanIsChecked = false;

            selectedViewModel = Functions[0]; 
        }

        private ApplicationViewModel _selectedViewModel;
        public ApplicationViewModel selectedViewModel {
            get { return _selectedViewModel;  }
            set
            {
                if (value != _selectedViewModel)
                {
                    _selectedViewModel = value;
                    OnPropertyChanged(nameof(selectedViewModel));
                    if(IsFileLoaded == true)
                    {
                        IsFileLoaded = false; 
                    }
                    if (selectedViewModel is LogFunction)
                    {
                        LogIsChecked = true;
                    }
                    else if (selectedViewModel is LinearFunction)
                    {
                        LinearIsChecked = true;
                    }
                    else if (selectedViewModel is SquareFunction)
                    {
                        SquareIsChecked = true;
                    }
                    else if (selectedViewModel is SinFunction)
                    {
                        SinIsChecked = true;
                    }
                    else if (selectedViewModel is CosFunction)
                    {
                        CosIsChecked = true;
                    }
                    else if (selectedViewModel is TanFunction) 
                    {
                        TanIsChecked = true;
                    }

                }   
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }

        public ObservableCollection<ApplicationViewModel> Functions { get; set; }


        private List<Point> _points;
        public List<Point> Points
        {
            get
            {
                return _points;
            }
            set
            {
                _points = value;
                OnPropertyChanged(nameof(Points));
            }
        } 


        public ICommand SaveCommand => new Command(SaveToFile);
        public ICommand LoadCommand => new Command(LoadFromFile);

        private void SaveToFile()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                DefaultExt = ".json"
            };
            if (saveFileDialog.ShowDialog() == true)
            {
                string json = JsonConvert.SerializeObject(selectedViewModel.Points);
                File.WriteAllText(saveFileDialog.FileName, json);
            }
        }

        private void LoadFromFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                DefaultExt = ".json"
            };
            if (openFileDialog.ShowDialog() == true)
            {
                string json = File.ReadAllText(openFileDialog.FileName);

                Points = JsonConvert.DeserializeObject<List<Point>>(json);
                OnPropertyChanged(nameof(Points));
                IsFileLoaded = true;
            }
        }

    }
}

