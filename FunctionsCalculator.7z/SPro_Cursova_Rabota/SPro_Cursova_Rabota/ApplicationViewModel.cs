﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace SPro_Cursova_Rabota
{
    public class ApplicationViewModel : INotifyPropertyChanged
    {
        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
                OnPropertyChanged("Name");
            }
        }
        private List<Point> _points;
        public List<Point> Points
        {
            get
            {
                return _points;
            }
            set
            {
                _points = value;
                OnPropertyChanged(nameof(Points)); 
            }
        }
        public ApplicationViewModel()
        {
            Command = new Command(Calculate);
        }


        virtual public void Calculate() { }


        private  double _maxX;
        private  double _maxY;

        public  double MaxX
        {
            get
            {
                return _maxX;
            }

            set
            {
                _maxX = value;
                OnPropertyChanged("MaxX");
            }
        }

        public  double MaxY
        {
            get
            {
                return _maxY;
            }

            set
            {
                _maxY = value;
                OnPropertyChanged("MaxY");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;



        public void OnPropertyChanged( string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }

        public ICommand Command {  get; set; }
    }
}
